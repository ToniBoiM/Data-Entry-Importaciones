﻿
namespace ImportacionesMain
{
    partial class Frm_Resumen_Add
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.layoutControl1 = new DevExpress.XtraLayout.LayoutControl();
            this.simpleButton2 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton1 = new DevExpress.XtraEditors.SimpleButton();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.layoutControl2 = new DevExpress.XtraLayout.LayoutControl();
            this.txtDescripcion = new DevExpress.XtraEditors.MemoEdit();
            this.dt_ETA = new DevExpress.XtraEditors.DateEdit();
            this.dt_ETD = new DevExpress.XtraEditors.DateEdit();
            this.cb_consignee = new DevExpress.XtraEditors.ComboBoxEdit();
            this.cb_carrier = new DevExpress.XtraEditors.ComboBoxEdit();
            this.cb_agente = new DevExpress.XtraEditors.ComboBoxEdit();
            this.sb_CrearConsignee = new DevExpress.XtraEditors.SimpleButton();
            this.sb_CrearCarrier = new DevExpress.XtraEditors.SimpleButton();
            this.sb_CrearPod = new DevExpress.XtraEditors.SimpleButton();
            this.sb_CrearPol = new DevExpress.XtraEditors.SimpleButton();
            this.sb_CrearAgente = new DevExpress.XtraEditors.SimpleButton();
            this.txtSize = new DevExpress.XtraEditors.TextEdit();
            this.txtREF = new DevExpress.XtraEditors.TextEdit();
            this.txtHBL = new DevExpress.XtraEditors.TextEdit();
            this.txtMBL = new DevExpress.XtraEditors.TextEdit();
            this.groupControl3 = new DevExpress.XtraEditors.GroupControl();
            this.layoutControl3 = new DevExpress.XtraLayout.LayoutControl();
            this.txtTlocal = new DevExpress.XtraEditors.TextEdit();
            this.txtCVLocal = new DevExpress.XtraEditors.TextEdit();
            this.txtDGastos = new DevExpress.XtraEditors.TextEdit();
            this.txtOtros = new DevExpress.XtraEditors.TextEdit();
            this.txtTHC = new DevExpress.XtraEditors.TextEdit();
            this.txtINLAN = new DevExpress.XtraEditors.TextEdit();
            this.txtOM = new DevExpress.XtraEditors.TextEdit();
            this.layoutControlGroup2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem17 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem18 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem19 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem21 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem26 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem27 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem38 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem10 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem11 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem12 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem13 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem14 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem15 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.txtBK = new DevExpress.XtraEditors.TextEdit();
            this.groupControl2 = new DevExpress.XtraEditors.GroupControl();
            this.layoutControl4 = new DevExpress.XtraLayout.LayoutControl();
            this.groupControl4 = new DevExpress.XtraEditors.GroupControl();
            this.layoutControl5 = new DevExpress.XtraLayout.LayoutControl();
            this.txtTEspecial = new DevExpress.XtraEditors.TextEdit();
            this.txtReintegro = new DevExpress.XtraEditors.TextEdit();
            this.txtRebate = new DevExpress.XtraEditors.TextEdit();
            this.layoutControlGroup4 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem29 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem30 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem39 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem21 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem22 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.sb_CrearIncoterm = new DevExpress.XtraEditors.SimpleButton();
            this.cb_incoterm = new DevExpress.XtraEditors.ComboBoxEdit();
            this.txtOTotal = new DevExpress.XtraEditors.TextEdit();
            this.txtQuotation = new DevExpress.XtraEditors.TextEdit();
            this.txtPAgent = new DevExpress.XtraEditors.TextEdit();
            this.txtOf = new DevExpress.XtraEditors.TextEdit();
            this.layoutControlGroup3 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem20 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem8 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem25 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem37 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem28 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem16 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem17 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem18 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem19 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem20 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.cb_Pod = new DevExpress.XtraEditors.ComboBoxEdit();
            this.cb_Pol = new DevExpress.XtraEditors.ComboBoxEdit();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem13 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem14 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem10 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem31 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem15 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem22 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem32 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem33 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem34 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem35 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem6 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem7 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem8 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem9 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem11 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem36 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem23 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem24 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem40 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem3 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.Root = new DevExpress.XtraLayout.LayoutControlGroup();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem12 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem9 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem16 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem4 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.behaviorManager1 = new DevExpress.Utils.Behaviors.BehaviorManager(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).BeginInit();
            this.layoutControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl2)).BeginInit();
            this.layoutControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtDescripcion.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dt_ETA.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dt_ETA.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dt_ETD.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dt_ETD.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cb_consignee.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cb_carrier.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cb_agente.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSize.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtREF.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHBL.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMBL.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl3)).BeginInit();
            this.groupControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl3)).BeginInit();
            this.layoutControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtTlocal.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCVLocal.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDGastos.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOtros.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTHC.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtINLAN.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOM.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBK.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).BeginInit();
            this.groupControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl4)).BeginInit();
            this.layoutControl4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl4)).BeginInit();
            this.groupControl4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl5)).BeginInit();
            this.layoutControl5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtTEspecial.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtReintegro.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRebate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cb_incoterm.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOTotal.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtQuotation.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPAgent.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOf.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cb_Pod.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cb_Pol.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Root)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.behaviorManager1)).BeginInit();
            this.SuspendLayout();
            // 
            // layoutControl1
            // 
            this.layoutControl1.Controls.Add(this.simpleButton2);
            this.layoutControl1.Controls.Add(this.simpleButton1);
            this.layoutControl1.Controls.Add(this.groupControl1);
            this.layoutControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layoutControl1.Location = new System.Drawing.Point(0, 0);
            this.layoutControl1.Name = "layoutControl1";
            this.layoutControl1.Root = this.Root;
            this.layoutControl1.Size = new System.Drawing.Size(1579, 939);
            this.layoutControl1.TabIndex = 0;
            this.layoutControl1.Text = "layoutControl1";
            // 
            // simpleButton2
            // 
            this.simpleButton2.ImageOptions.Image = global::ImportacionesMain.Properties.Resources.close_32x32;
            this.simpleButton2.Location = new System.Drawing.Point(1191, 866);
            this.simpleButton2.Name = "simpleButton2";
            this.simpleButton2.Size = new System.Drawing.Size(376, 36);
            this.simpleButton2.StyleController = this.layoutControl1;
            this.simpleButton2.TabIndex = 17;
            this.simpleButton2.Text = "Cerrar";
            this.simpleButton2.Click += new System.EventHandler(this.simpleButton2_Click);
            // 
            // simpleButton1
            // 
            this.simpleButton1.ImageOptions.Image = global::ImportacionesMain.Properties.Resources.Ribbon_Save_32x32;
            this.simpleButton1.Location = new System.Drawing.Point(819, 866);
            this.simpleButton1.Name = "simpleButton1";
            this.simpleButton1.Size = new System.Drawing.Size(368, 36);
            this.simpleButton1.StyleController = this.layoutControl1;
            this.simpleButton1.TabIndex = 16;
            this.simpleButton1.Text = "Guardar";
            this.simpleButton1.Click += new System.EventHandler(this.simpleButton1_Click);
            // 
            // groupControl1
            // 
            this.groupControl1.Controls.Add(this.layoutControl2);
            this.groupControl1.Location = new System.Drawing.Point(12, 12);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(1555, 850);
            this.groupControl1.TabIndex = 15;
            this.groupControl1.Text = "Datos";
            // 
            // layoutControl2
            // 
            this.layoutControl2.Controls.Add(this.txtDescripcion);
            this.layoutControl2.Controls.Add(this.dt_ETA);
            this.layoutControl2.Controls.Add(this.dt_ETD);
            this.layoutControl2.Controls.Add(this.cb_consignee);
            this.layoutControl2.Controls.Add(this.cb_carrier);
            this.layoutControl2.Controls.Add(this.cb_agente);
            this.layoutControl2.Controls.Add(this.sb_CrearConsignee);
            this.layoutControl2.Controls.Add(this.sb_CrearCarrier);
            this.layoutControl2.Controls.Add(this.sb_CrearPod);
            this.layoutControl2.Controls.Add(this.sb_CrearPol);
            this.layoutControl2.Controls.Add(this.sb_CrearAgente);
            this.layoutControl2.Controls.Add(this.txtSize);
            this.layoutControl2.Controls.Add(this.txtREF);
            this.layoutControl2.Controls.Add(this.txtHBL);
            this.layoutControl2.Controls.Add(this.txtMBL);
            this.layoutControl2.Controls.Add(this.groupControl3);
            this.layoutControl2.Controls.Add(this.txtBK);
            this.layoutControl2.Controls.Add(this.groupControl2);
            this.layoutControl2.Controls.Add(this.cb_Pod);
            this.layoutControl2.Controls.Add(this.cb_Pol);
            this.layoutControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layoutControl2.Location = new System.Drawing.Point(2, 28);
            this.layoutControl2.Name = "layoutControl2";
            this.layoutControl2.Root = this.layoutControlGroup1;
            this.layoutControl2.Size = new System.Drawing.Size(1551, 820);
            this.layoutControl2.TabIndex = 6;
            this.layoutControl2.Text = "layoutControl2";
            // 
            // txtDescripcion
            // 
            this.txtDescripcion.Location = new System.Drawing.Point(133, 242);
            this.txtDescripcion.Name = "txtDescripcion";
            this.txtDescripcion.Size = new System.Drawing.Size(1406, 71);
            this.txtDescripcion.StyleController = this.layoutControl2;
            this.txtDescripcion.TabIndex = 37;
            // 
            // dt_ETA
            // 
            this.dt_ETA.EditValue = null;
            this.dt_ETA.Location = new System.Drawing.Point(897, 196);
            this.dt_ETA.Name = "dt_ETA";
            this.dt_ETA.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.dt_ETA.Properties.Appearance.Options.UseFont = true;
            this.dt_ETA.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dt_ETA.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dt_ETA.Size = new System.Drawing.Size(642, 30);
            this.dt_ETA.StyleController = this.layoutControl2;
            this.dt_ETA.TabIndex = 36;
            // 
            // dt_ETD
            // 
            this.dt_ETD.EditValue = null;
            this.dt_ETD.Location = new System.Drawing.Point(133, 196);
            this.dt_ETD.Name = "dt_ETD";
            this.dt_ETD.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.dt_ETD.Properties.Appearance.Options.UseFont = true;
            this.dt_ETD.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dt_ETD.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dt_ETD.Size = new System.Drawing.Size(639, 30);
            this.dt_ETD.StyleController = this.layoutControl2;
            this.dt_ETD.TabIndex = 35;
            // 
            // cb_consignee
            // 
            this.cb_consignee.Location = new System.Drawing.Point(902, 58);
            this.cb_consignee.Name = "cb_consignee";
            this.cb_consignee.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.cb_consignee.Properties.Appearance.Options.UseFont = true;
            this.cb_consignee.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cb_consignee.Size = new System.Drawing.Size(254, 30);
            this.cb_consignee.StyleController = this.layoutControl2;
            this.cb_consignee.TabIndex = 34;
            // 
            // cb_carrier
            // 
            this.cb_carrier.Location = new System.Drawing.Point(133, 58);
            this.cb_carrier.Name = "cb_carrier";
            this.cb_carrier.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cb_carrier.Size = new System.Drawing.Size(259, 22);
            this.cb_carrier.StyleController = this.layoutControl2;
            this.cb_carrier.TabIndex = 33;
            // 
            // cb_agente
            // 
            this.cb_agente.Location = new System.Drawing.Point(133, 12);
            this.cb_agente.Name = "cb_agente";
            this.cb_agente.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cb_agente.Size = new System.Drawing.Size(216, 22);
            this.cb_agente.StyleController = this.layoutControl2;
            this.cb_agente.TabIndex = 32;
            // 
            // sb_CrearConsignee
            // 
            this.sb_CrearConsignee.Appearance.Font = new System.Drawing.Font("Tahoma", 8F);
            this.sb_CrearConsignee.Appearance.Options.UseFont = true;
            this.sb_CrearConsignee.ImageOptions.Image = global::ImportacionesMain.Properties.Resources.Add_1_16;
            this.sb_CrearConsignee.Location = new System.Drawing.Point(1160, 58);
            this.sb_CrearConsignee.Name = "sb_CrearConsignee";
            this.sb_CrearConsignee.Size = new System.Drawing.Size(379, 27);
            this.sb_CrearConsignee.StyleController = this.layoutControl2;
            this.sb_CrearConsignee.TabIndex = 30;
            this.sb_CrearConsignee.Text = "Crear Consignee";
            this.sb_CrearConsignee.Click += new System.EventHandler(this.sb_CrearConsignee_Click);
            // 
            // sb_CrearCarrier
            // 
            this.sb_CrearCarrier.Appearance.Font = new System.Drawing.Font("Tahoma", 8F);
            this.sb_CrearCarrier.Appearance.Options.UseFont = true;
            this.sb_CrearCarrier.ImageOptions.Image = global::ImportacionesMain.Properties.Resources.Add_1_16;
            this.sb_CrearCarrier.Location = new System.Drawing.Point(396, 58);
            this.sb_CrearCarrier.Name = "sb_CrearCarrier";
            this.sb_CrearCarrier.Size = new System.Drawing.Size(381, 27);
            this.sb_CrearCarrier.StyleController = this.layoutControl2;
            this.sb_CrearCarrier.TabIndex = 29;
            this.sb_CrearCarrier.Text = "Crear Carrier";
            this.sb_CrearCarrier.Click += new System.EventHandler(this.sb_CrearCarrier_Click);
            // 
            // sb_CrearPod
            // 
            this.sb_CrearPod.Appearance.Font = new System.Drawing.Font("Tahoma", 8F);
            this.sb_CrearPod.Appearance.Options.UseFont = true;
            this.sb_CrearPod.ImageOptions.Image = global::ImportacionesMain.Properties.Resources.Add_1_16;
            this.sb_CrearPod.Location = new System.Drawing.Point(1412, 12);
            this.sb_CrearPod.Name = "sb_CrearPod";
            this.sb_CrearPod.Size = new System.Drawing.Size(127, 27);
            this.sb_CrearPod.StyleController = this.layoutControl2;
            this.sb_CrearPod.TabIndex = 28;
            this.sb_CrearPod.Text = "Crear POD";
            this.sb_CrearPod.Click += new System.EventHandler(this.sb_CrearPod_Click);
            // 
            // sb_CrearPol
            // 
            this.sb_CrearPol.Appearance.Font = new System.Drawing.Font("Tahoma", 8F);
            this.sb_CrearPol.Appearance.Options.UseFont = true;
            this.sb_CrearPol.ImageOptions.Image = global::ImportacionesMain.Properties.Resources.Add_1_16;
            this.sb_CrearPol.Location = new System.Drawing.Point(882, 12);
            this.sb_CrearPol.Name = "sb_CrearPol";
            this.sb_CrearPol.Size = new System.Drawing.Size(147, 27);
            this.sb_CrearPol.StyleController = this.layoutControl2;
            this.sb_CrearPol.TabIndex = 27;
            this.sb_CrearPol.Text = "Crear POL";
            this.sb_CrearPol.Click += new System.EventHandler(this.sb_CrearPol_Click);
            // 
            // sb_CrearAgente
            // 
            this.sb_CrearAgente.Appearance.Font = new System.Drawing.Font("Tahoma", 8F);
            this.sb_CrearAgente.Appearance.ForeColor = System.Drawing.Color.Black;
            this.sb_CrearAgente.Appearance.Options.UseFont = true;
            this.sb_CrearAgente.Appearance.Options.UseForeColor = true;
            this.sb_CrearAgente.ImageOptions.Image = global::ImportacionesMain.Properties.Resources.Add_1_16;
            this.sb_CrearAgente.Location = new System.Drawing.Point(353, 12);
            this.sb_CrearAgente.Name = "sb_CrearAgente";
            this.sb_CrearAgente.Size = new System.Drawing.Size(166, 27);
            this.sb_CrearAgente.StyleController = this.layoutControl2;
            this.sb_CrearAgente.TabIndex = 26;
            this.sb_CrearAgente.Text = "Crear Agente";
            this.sb_CrearAgente.Click += new System.EventHandler(this.sb_CrearAgente_Click);
            // 
            // txtSize
            // 
            this.txtSize.Location = new System.Drawing.Point(897, 150);
            this.txtSize.Name = "txtSize";
            this.txtSize.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtSize.Properties.Appearance.Options.UseFont = true;
            this.txtSize.Size = new System.Drawing.Size(642, 30);
            this.txtSize.StyleController = this.layoutControl2;
            this.txtSize.TabIndex = 23;
            // 
            // txtREF
            // 
            this.txtREF.Location = new System.Drawing.Point(133, 150);
            this.txtREF.Name = "txtREF";
            this.txtREF.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtREF.Properties.Appearance.Options.UseFont = true;
            this.txtREF.Size = new System.Drawing.Size(639, 30);
            this.txtREF.StyleController = this.layoutControl2;
            this.txtREF.TabIndex = 20;
            // 
            // txtHBL
            // 
            this.txtHBL.Location = new System.Drawing.Point(643, 104);
            this.txtHBL.Name = "txtHBL";
            this.txtHBL.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtHBL.Properties.Appearance.Options.UseFont = true;
            this.txtHBL.Size = new System.Drawing.Size(384, 30);
            this.txtHBL.StyleController = this.layoutControl2;
            this.txtHBL.TabIndex = 19;
            // 
            // txtMBL
            // 
            this.txtMBL.Location = new System.Drawing.Point(1152, 104);
            this.txtMBL.Name = "txtMBL";
            this.txtMBL.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtMBL.Properties.Appearance.Options.UseFont = true;
            this.txtMBL.Size = new System.Drawing.Size(387, 30);
            this.txtMBL.StyleController = this.layoutControl2;
            this.txtMBL.TabIndex = 18;
            // 
            // groupControl3
            // 
            this.groupControl3.Controls.Add(this.layoutControl3);
            this.groupControl3.Location = new System.Drawing.Point(776, 317);
            this.groupControl3.Name = "groupControl3";
            this.groupControl3.Size = new System.Drawing.Size(763, 491);
            this.groupControl3.TabIndex = 17;
            this.groupControl3.Text = "Cargos Locales";
            // 
            // layoutControl3
            // 
            this.layoutControl3.Controls.Add(this.txtTlocal);
            this.layoutControl3.Controls.Add(this.txtCVLocal);
            this.layoutControl3.Controls.Add(this.txtDGastos);
            this.layoutControl3.Controls.Add(this.txtOtros);
            this.layoutControl3.Controls.Add(this.txtTHC);
            this.layoutControl3.Controls.Add(this.txtINLAN);
            this.layoutControl3.Controls.Add(this.txtOM);
            this.layoutControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layoutControl3.Location = new System.Drawing.Point(2, 28);
            this.layoutControl3.Name = "layoutControl3";
            this.layoutControl3.Root = this.layoutControlGroup2;
            this.layoutControl3.Size = new System.Drawing.Size(759, 461);
            this.layoutControl3.TabIndex = 0;
            this.layoutControl3.Text = "layoutControl3";
            // 
            // txtTlocal
            // 
            this.txtTlocal.Location = new System.Drawing.Point(248, 352);
            this.txtTlocal.Name = "txtTlocal";
            this.txtTlocal.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtTlocal.Properties.Appearance.Options.UseFont = true;
            this.txtTlocal.Size = new System.Drawing.Size(499, 30);
            this.txtTlocal.StyleController = this.layoutControl3;
            this.txtTlocal.TabIndex = 10;
            // 
            // txtCVLocal
            // 
            this.txtCVLocal.Location = new System.Drawing.Point(248, 292);
            this.txtCVLocal.Name = "txtCVLocal";
            this.txtCVLocal.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtCVLocal.Properties.Appearance.Options.UseFont = true;
            this.txtCVLocal.Size = new System.Drawing.Size(499, 30);
            this.txtCVLocal.StyleController = this.layoutControl3;
            this.txtCVLocal.TabIndex = 9;
            // 
            // txtDGastos
            // 
            this.txtDGastos.Location = new System.Drawing.Point(248, 234);
            this.txtDGastos.Name = "txtDGastos";
            this.txtDGastos.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtDGastos.Properties.Appearance.Options.UseFont = true;
            this.txtDGastos.Size = new System.Drawing.Size(499, 30);
            this.txtDGastos.StyleController = this.layoutControl3;
            this.txtDGastos.TabIndex = 8;
            // 
            // txtOtros
            // 
            this.txtOtros.Location = new System.Drawing.Point(248, 178);
            this.txtOtros.Name = "txtOtros";
            this.txtOtros.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtOtros.Properties.Appearance.Options.UseFont = true;
            this.txtOtros.Size = new System.Drawing.Size(499, 30);
            this.txtOtros.StyleController = this.layoutControl3;
            this.txtOtros.TabIndex = 7;
            // 
            // txtTHC
            // 
            this.txtTHC.Location = new System.Drawing.Point(248, 122);
            this.txtTHC.Name = "txtTHC";
            this.txtTHC.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtTHC.Properties.Appearance.Options.UseFont = true;
            this.txtTHC.Size = new System.Drawing.Size(499, 30);
            this.txtTHC.StyleController = this.layoutControl3;
            this.txtTHC.TabIndex = 6;
            // 
            // txtINLAN
            // 
            this.txtINLAN.Location = new System.Drawing.Point(248, 67);
            this.txtINLAN.Name = "txtINLAN";
            this.txtINLAN.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtINLAN.Properties.Appearance.Options.UseFont = true;
            this.txtINLAN.Size = new System.Drawing.Size(499, 30);
            this.txtINLAN.StyleController = this.layoutControl3;
            this.txtINLAN.TabIndex = 5;
            // 
            // txtOM
            // 
            this.txtOM.Location = new System.Drawing.Point(248, 12);
            this.txtOM.Name = "txtOM";
            this.txtOM.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtOM.Properties.Appearance.Options.UseFont = true;
            this.txtOM.Size = new System.Drawing.Size(499, 30);
            this.txtOM.StyleController = this.layoutControl3;
            this.txtOM.TabIndex = 4;
            // 
            // layoutControlGroup2
            // 
            this.layoutControlGroup2.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup2.GroupBordersVisible = false;
            this.layoutControlGroup2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem2,
            this.layoutControlItem17,
            this.layoutControlItem18,
            this.layoutControlItem19,
            this.layoutControlItem21,
            this.layoutControlItem26,
            this.layoutControlItem27,
            this.layoutControlItem38,
            this.emptySpaceItem10,
            this.emptySpaceItem11,
            this.emptySpaceItem12,
            this.emptySpaceItem13,
            this.emptySpaceItem14,
            this.emptySpaceItem15});
            this.layoutControlGroup2.Name = "layoutControlGroup2";
            this.layoutControlGroup2.Size = new System.Drawing.Size(759, 461);
            this.layoutControlGroup2.TextVisible = false;
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.Location = new System.Drawing.Point(0, 374);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(739, 67);
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem17
            // 
            this.layoutControlItem17.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 12F);
            this.layoutControlItem17.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem17.Control = this.txtOM;
            this.layoutControlItem17.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem17.Name = "layoutControlItem17";
            this.layoutControlItem17.Size = new System.Drawing.Size(739, 34);
            this.layoutControlItem17.Text = "OM";
            this.layoutControlItem17.TextSize = new System.Drawing.Size(224, 24);
            // 
            // layoutControlItem18
            // 
            this.layoutControlItem18.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 12F);
            this.layoutControlItem18.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem18.Control = this.txtINLAN;
            this.layoutControlItem18.Location = new System.Drawing.Point(0, 55);
            this.layoutControlItem18.Name = "layoutControlItem18";
            this.layoutControlItem18.Size = new System.Drawing.Size(739, 34);
            this.layoutControlItem18.Text = "INLAN CTO-MGA";
            this.layoutControlItem18.TextSize = new System.Drawing.Size(224, 24);
            // 
            // layoutControlItem19
            // 
            this.layoutControlItem19.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 12F);
            this.layoutControlItem19.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem19.Control = this.txtTHC;
            this.layoutControlItem19.Location = new System.Drawing.Point(0, 110);
            this.layoutControlItem19.Name = "layoutControlItem19";
            this.layoutControlItem19.Size = new System.Drawing.Size(739, 34);
            this.layoutControlItem19.Text = "THC";
            this.layoutControlItem19.TextSize = new System.Drawing.Size(224, 24);
            // 
            // layoutControlItem21
            // 
            this.layoutControlItem21.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 12F);
            this.layoutControlItem21.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem21.Control = this.txtOtros;
            this.layoutControlItem21.Location = new System.Drawing.Point(0, 166);
            this.layoutControlItem21.Name = "layoutControlItem21";
            this.layoutControlItem21.Size = new System.Drawing.Size(739, 34);
            this.layoutControlItem21.Text = "OTROS";
            this.layoutControlItem21.TextSize = new System.Drawing.Size(224, 24);
            // 
            // layoutControlItem26
            // 
            this.layoutControlItem26.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 12F);
            this.layoutControlItem26.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem26.Control = this.txtDGastos;
            this.layoutControlItem26.Location = new System.Drawing.Point(0, 222);
            this.layoutControlItem26.Name = "layoutControlItem26";
            this.layoutControlItem26.Size = new System.Drawing.Size(739, 34);
            this.layoutControlItem26.Text = "Descripción Otros Gastos";
            this.layoutControlItem26.TextSize = new System.Drawing.Size(224, 24);
            // 
            // layoutControlItem27
            // 
            this.layoutControlItem27.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 12F);
            this.layoutControlItem27.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem27.Control = this.txtCVLocal;
            this.layoutControlItem27.Location = new System.Drawing.Point(0, 280);
            this.layoutControlItem27.Name = "layoutControlItem27";
            this.layoutControlItem27.Size = new System.Drawing.Size(739, 34);
            this.layoutControlItem27.Text = "Comisión Vendedor Local";
            this.layoutControlItem27.TextSize = new System.Drawing.Size(224, 24);
            // 
            // layoutControlItem38
            // 
            this.layoutControlItem38.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 12F);
            this.layoutControlItem38.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem38.Control = this.txtTlocal;
            this.layoutControlItem38.Location = new System.Drawing.Point(0, 340);
            this.layoutControlItem38.Name = "layoutControlItem38";
            this.layoutControlItem38.Size = new System.Drawing.Size(739, 34);
            this.layoutControlItem38.Text = "Total";
            this.layoutControlItem38.TextSize = new System.Drawing.Size(224, 24);
            // 
            // emptySpaceItem10
            // 
            this.emptySpaceItem10.AllowHotTrack = false;
            this.emptySpaceItem10.Location = new System.Drawing.Point(0, 34);
            this.emptySpaceItem10.Name = "emptySpaceItem10";
            this.emptySpaceItem10.Size = new System.Drawing.Size(739, 21);
            this.emptySpaceItem10.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem11
            // 
            this.emptySpaceItem11.AllowHotTrack = false;
            this.emptySpaceItem11.Location = new System.Drawing.Point(0, 89);
            this.emptySpaceItem11.Name = "emptySpaceItem11";
            this.emptySpaceItem11.Size = new System.Drawing.Size(739, 21);
            this.emptySpaceItem11.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem12
            // 
            this.emptySpaceItem12.AllowHotTrack = false;
            this.emptySpaceItem12.Location = new System.Drawing.Point(0, 144);
            this.emptySpaceItem12.Name = "emptySpaceItem12";
            this.emptySpaceItem12.Size = new System.Drawing.Size(739, 22);
            this.emptySpaceItem12.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem13
            // 
            this.emptySpaceItem13.AllowHotTrack = false;
            this.emptySpaceItem13.Location = new System.Drawing.Point(0, 200);
            this.emptySpaceItem13.Name = "emptySpaceItem13";
            this.emptySpaceItem13.Size = new System.Drawing.Size(739, 22);
            this.emptySpaceItem13.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem14
            // 
            this.emptySpaceItem14.AllowHotTrack = false;
            this.emptySpaceItem14.Location = new System.Drawing.Point(0, 256);
            this.emptySpaceItem14.Name = "emptySpaceItem14";
            this.emptySpaceItem14.Size = new System.Drawing.Size(739, 24);
            this.emptySpaceItem14.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem15
            // 
            this.emptySpaceItem15.AllowHotTrack = false;
            this.emptySpaceItem15.Location = new System.Drawing.Point(0, 314);
            this.emptySpaceItem15.Name = "emptySpaceItem15";
            this.emptySpaceItem15.Size = new System.Drawing.Size(739, 26);
            this.emptySpaceItem15.TextSize = new System.Drawing.Size(0, 0);
            // 
            // txtBK
            // 
            this.txtBK.Location = new System.Drawing.Point(133, 104);
            this.txtBK.Name = "txtBK";
            this.txtBK.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtBK.Properties.Appearance.Options.UseFont = true;
            this.txtBK.Size = new System.Drawing.Size(385, 30);
            this.txtBK.StyleController = this.layoutControl2;
            this.txtBK.TabIndex = 14;
            // 
            // groupControl2
            // 
            this.groupControl2.Controls.Add(this.layoutControl4);
            this.groupControl2.Location = new System.Drawing.Point(12, 317);
            this.groupControl2.Name = "groupControl2";
            this.groupControl2.Size = new System.Drawing.Size(760, 491);
            this.groupControl2.TabIndex = 16;
            this.groupControl2.Text = "Cargos Origen";
            // 
            // layoutControl4
            // 
            this.layoutControl4.Controls.Add(this.groupControl4);
            this.layoutControl4.Controls.Add(this.sb_CrearIncoterm);
            this.layoutControl4.Controls.Add(this.cb_incoterm);
            this.layoutControl4.Controls.Add(this.txtOTotal);
            this.layoutControl4.Controls.Add(this.txtQuotation);
            this.layoutControl4.Controls.Add(this.txtPAgent);
            this.layoutControl4.Controls.Add(this.txtOf);
            this.layoutControl4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layoutControl4.Location = new System.Drawing.Point(2, 28);
            this.layoutControl4.Name = "layoutControl4";
            this.layoutControl4.Root = this.layoutControlGroup3;
            this.layoutControl4.Size = new System.Drawing.Size(756, 461);
            this.layoutControl4.TabIndex = 0;
            this.layoutControl4.Text = "layoutControl4";
            // 
            // groupControl4
            // 
            this.groupControl4.Controls.Add(this.layoutControl5);
            this.groupControl4.Location = new System.Drawing.Point(12, 272);
            this.groupControl4.Name = "groupControl4";
            this.groupControl4.Size = new System.Drawing.Size(732, 177);
            this.groupControl4.TabIndex = 10;
            this.groupControl4.Text = "Manejo Especial";
            // 
            // layoutControl5
            // 
            this.layoutControl5.Controls.Add(this.txtTEspecial);
            this.layoutControl5.Controls.Add(this.txtReintegro);
            this.layoutControl5.Controls.Add(this.txtRebate);
            this.layoutControl5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layoutControl5.Location = new System.Drawing.Point(2, 28);
            this.layoutControl5.Name = "layoutControl5";
            this.layoutControl5.Root = this.layoutControlGroup4;
            this.layoutControl5.Size = new System.Drawing.Size(728, 147);
            this.layoutControl5.TabIndex = 0;
            this.layoutControl5.Text = "layoutControl5";
            // 
            // txtTEspecial
            // 
            this.txtTEspecial.Location = new System.Drawing.Point(110, 105);
            this.txtTEspecial.Name = "txtTEspecial";
            this.txtTEspecial.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtTEspecial.Properties.Appearance.Options.UseFont = true;
            this.txtTEspecial.Size = new System.Drawing.Size(606, 30);
            this.txtTEspecial.StyleController = this.layoutControl5;
            this.txtTEspecial.TabIndex = 11;
            // 
            // txtReintegro
            // 
            this.txtReintegro.Location = new System.Drawing.Point(110, 56);
            this.txtReintegro.Name = "txtReintegro";
            this.txtReintegro.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtReintegro.Properties.Appearance.Options.UseFont = true;
            this.txtReintegro.Size = new System.Drawing.Size(606, 30);
            this.txtReintegro.StyleController = this.layoutControl5;
            this.txtReintegro.TabIndex = 5;
            // 
            // txtRebate
            // 
            this.txtRebate.EditValue = "";
            this.txtRebate.Location = new System.Drawing.Point(110, 12);
            this.txtRebate.Name = "txtRebate";
            this.txtRebate.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtRebate.Properties.Appearance.Options.UseFont = true;
            this.txtRebate.Size = new System.Drawing.Size(606, 30);
            this.txtRebate.StyleController = this.layoutControl5;
            this.txtRebate.TabIndex = 4;
            // 
            // layoutControlGroup4
            // 
            this.layoutControlGroup4.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup4.GroupBordersVisible = false;
            this.layoutControlGroup4.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem29,
            this.layoutControlItem30,
            this.layoutControlItem39,
            this.emptySpaceItem21,
            this.emptySpaceItem22});
            this.layoutControlGroup4.Name = "layoutControlGroup4";
            this.layoutControlGroup4.Size = new System.Drawing.Size(728, 147);
            this.layoutControlGroup4.TextVisible = false;
            // 
            // layoutControlItem29
            // 
            this.layoutControlItem29.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 12F);
            this.layoutControlItem29.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem29.Control = this.txtRebate;
            this.layoutControlItem29.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem29.Name = "layoutControlItem29";
            this.layoutControlItem29.Size = new System.Drawing.Size(708, 34);
            this.layoutControlItem29.Text = "Rebate";
            this.layoutControlItem29.TextSize = new System.Drawing.Size(86, 24);
            // 
            // layoutControlItem30
            // 
            this.layoutControlItem30.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 12F);
            this.layoutControlItem30.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem30.Control = this.txtReintegro;
            this.layoutControlItem30.Location = new System.Drawing.Point(0, 44);
            this.layoutControlItem30.Name = "layoutControlItem30";
            this.layoutControlItem30.Size = new System.Drawing.Size(708, 28);
            this.layoutControlItem30.Text = "Reintegro";
            this.layoutControlItem30.TextSize = new System.Drawing.Size(86, 24);
            // 
            // layoutControlItem39
            // 
            this.layoutControlItem39.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 12F);
            this.layoutControlItem39.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem39.Control = this.txtTEspecial;
            this.layoutControlItem39.Location = new System.Drawing.Point(0, 93);
            this.layoutControlItem39.Name = "layoutControlItem39";
            this.layoutControlItem39.Size = new System.Drawing.Size(708, 34);
            this.layoutControlItem39.Text = "Total";
            this.layoutControlItem39.TextSize = new System.Drawing.Size(86, 24);
            // 
            // emptySpaceItem21
            // 
            this.emptySpaceItem21.AllowHotTrack = false;
            this.emptySpaceItem21.Location = new System.Drawing.Point(0, 34);
            this.emptySpaceItem21.Name = "emptySpaceItem21";
            this.emptySpaceItem21.Size = new System.Drawing.Size(708, 10);
            this.emptySpaceItem21.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem22
            // 
            this.emptySpaceItem22.AllowHotTrack = false;
            this.emptySpaceItem22.Location = new System.Drawing.Point(0, 72);
            this.emptySpaceItem22.Name = "emptySpaceItem22";
            this.emptySpaceItem22.Size = new System.Drawing.Size(708, 21);
            this.emptySpaceItem22.TextSize = new System.Drawing.Size(0, 0);
            // 
            // sb_CrearIncoterm
            // 
            this.sb_CrearIncoterm.ImageOptions.Image = global::ImportacionesMain.Properties.Resources.Add_1_16;
            this.sb_CrearIncoterm.Location = new System.Drawing.Point(585, 120);
            this.sb_CrearIncoterm.Name = "sb_CrearIncoterm";
            this.sb_CrearIncoterm.Size = new System.Drawing.Size(159, 27);
            this.sb_CrearIncoterm.StyleController = this.layoutControl4;
            this.sb_CrearIncoterm.TabIndex = 19;
            this.sb_CrearIncoterm.Text = "Crear INCOTERM";
            this.sb_CrearIncoterm.Click += new System.EventHandler(this.sb_CrearIncoterm_Click);
            // 
            // cb_incoterm
            // 
            this.cb_incoterm.Location = new System.Drawing.Point(133, 120);
            this.cb_incoterm.Name = "cb_incoterm";
            this.cb_incoterm.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.cb_incoterm.Properties.Appearance.Options.UseFont = true;
            this.cb_incoterm.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cb_incoterm.Size = new System.Drawing.Size(448, 30);
            this.cb_incoterm.StyleController = this.layoutControl4;
            this.cb_incoterm.TabIndex = 18;
            // 
            // txtOTotal
            // 
            this.txtOTotal.Location = new System.Drawing.Point(133, 217);
            this.txtOTotal.Name = "txtOTotal";
            this.txtOTotal.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtOTotal.Properties.Appearance.Options.UseFont = true;
            this.txtOTotal.Properties.ReadOnly = true;
            this.txtOTotal.Size = new System.Drawing.Size(611, 30);
            this.txtOTotal.StyleController = this.layoutControl4;
            this.txtOTotal.TabIndex = 17;
            // 
            // txtQuotation
            // 
            this.txtQuotation.Location = new System.Drawing.Point(133, 164);
            this.txtQuotation.Name = "txtQuotation";
            this.txtQuotation.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtQuotation.Properties.Appearance.Options.UseFont = true;
            this.txtQuotation.Size = new System.Drawing.Size(611, 30);
            this.txtQuotation.StyleController = this.layoutControl4;
            this.txtQuotation.TabIndex = 16;
            this.txtQuotation.EditValueChanged += new System.EventHandler(this.txtQuotation_EditValueChanged);
            this.txtQuotation.Leave += new System.EventHandler(this.txtQuotation_Leave);
            // 
            // txtPAgent
            // 
            this.txtPAgent.Location = new System.Drawing.Point(133, 66);
            this.txtPAgent.Name = "txtPAgent";
            this.txtPAgent.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtPAgent.Properties.Appearance.Options.UseFont = true;
            this.txtPAgent.Size = new System.Drawing.Size(611, 30);
            this.txtPAgent.StyleController = this.layoutControl4;
            this.txtPAgent.TabIndex = 14;
            this.txtPAgent.EditValueChanged += new System.EventHandler(this.txtPAgent_EditValueChanged);
            this.txtPAgent.Leave += new System.EventHandler(this.txtPAgent_Leave);
            // 
            // txtOf
            // 
            this.txtOf.Location = new System.Drawing.Point(133, 12);
            this.txtOf.Name = "txtOf";
            this.txtOf.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.txtOf.Properties.Appearance.Options.UseFont = true;
            this.txtOf.Properties.BeepOnError = false;
            this.txtOf.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtOf.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.NumericMaskManager));
            this.txtOf.Properties.MaskSettings.Set("MaskManagerSignature", "allowNull=False");
            this.txtOf.Properties.MaskSettings.Set("mask", "c");
            this.txtOf.Size = new System.Drawing.Size(611, 30);
            this.txtOf.StyleController = this.layoutControl4;
            this.txtOf.TabIndex = 13;
            this.txtOf.EditValueChanged += new System.EventHandler(this.txtOf_EditValueChanged);
            this.txtOf.Leave += new System.EventHandler(this.txtOf_Leave);
            // 
            // layoutControlGroup3
            // 
            this.layoutControlGroup3.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup3.GroupBordersVisible = false;
            this.layoutControlGroup3.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem20,
            this.layoutControlItem4,
            this.layoutControlItem8,
            this.layoutControlItem25,
            this.layoutControlItem6,
            this.layoutControlItem37,
            this.layoutControlItem28,
            this.emptySpaceItem16,
            this.emptySpaceItem17,
            this.emptySpaceItem18,
            this.emptySpaceItem19,
            this.emptySpaceItem20});
            this.layoutControlGroup3.Name = "layoutControlGroup3";
            this.layoutControlGroup3.Size = new System.Drawing.Size(756, 461);
            this.layoutControlGroup3.TextVisible = false;
            // 
            // layoutControlItem20
            // 
            this.layoutControlItem20.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 12F);
            this.layoutControlItem20.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem20.Control = this.txtOf;
            this.layoutControlItem20.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem20.Name = "layoutControlItem20";
            this.layoutControlItem20.Size = new System.Drawing.Size(736, 34);
            this.layoutControlItem20.Text = "OF";
            this.layoutControlItem20.TextSize = new System.Drawing.Size(109, 24);
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 12F);
            this.layoutControlItem4.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem4.Control = this.txtPAgent;
            this.layoutControlItem4.Location = new System.Drawing.Point(0, 54);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(736, 34);
            this.layoutControlItem4.Text = "Profit Agent";
            this.layoutControlItem4.TextSize = new System.Drawing.Size(109, 24);
            // 
            // layoutControlItem8
            // 
            this.layoutControlItem8.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 12F);
            this.layoutControlItem8.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem8.Control = this.txtQuotation;
            this.layoutControlItem8.Location = new System.Drawing.Point(0, 152);
            this.layoutControlItem8.Name = "layoutControlItem8";
            this.layoutControlItem8.Size = new System.Drawing.Size(736, 34);
            this.layoutControlItem8.Text = "Quotation #";
            this.layoutControlItem8.TextSize = new System.Drawing.Size(109, 24);
            // 
            // layoutControlItem25
            // 
            this.layoutControlItem25.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 12F);
            this.layoutControlItem25.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem25.Control = this.txtOTotal;
            this.layoutControlItem25.Location = new System.Drawing.Point(0, 205);
            this.layoutControlItem25.Name = "layoutControlItem25";
            this.layoutControlItem25.Size = new System.Drawing.Size(736, 34);
            this.layoutControlItem25.Text = "Total";
            this.layoutControlItem25.TextSize = new System.Drawing.Size(109, 24);
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 12F);
            this.layoutControlItem6.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem6.Control = this.cb_incoterm;
            this.layoutControlItem6.Location = new System.Drawing.Point(0, 108);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(573, 34);
            this.layoutControlItem6.Text = "INCOTERM";
            this.layoutControlItem6.TextSize = new System.Drawing.Size(109, 24);
            // 
            // layoutControlItem37
            // 
            this.layoutControlItem37.Control = this.sb_CrearIncoterm;
            this.layoutControlItem37.Location = new System.Drawing.Point(573, 108);
            this.layoutControlItem37.Name = "layoutControlItem37";
            this.layoutControlItem37.Size = new System.Drawing.Size(163, 44);
            this.layoutControlItem37.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem37.TextVisible = false;
            // 
            // layoutControlItem28
            // 
            this.layoutControlItem28.Control = this.groupControl4;
            this.layoutControlItem28.Location = new System.Drawing.Point(0, 260);
            this.layoutControlItem28.Name = "layoutControlItem28";
            this.layoutControlItem28.Size = new System.Drawing.Size(736, 181);
            this.layoutControlItem28.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem28.TextVisible = false;
            // 
            // emptySpaceItem16
            // 
            this.emptySpaceItem16.AllowHotTrack = false;
            this.emptySpaceItem16.Location = new System.Drawing.Point(0, 34);
            this.emptySpaceItem16.Name = "emptySpaceItem16";
            this.emptySpaceItem16.Size = new System.Drawing.Size(736, 20);
            this.emptySpaceItem16.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem17
            // 
            this.emptySpaceItem17.AllowHotTrack = false;
            this.emptySpaceItem17.Location = new System.Drawing.Point(0, 88);
            this.emptySpaceItem17.Name = "emptySpaceItem17";
            this.emptySpaceItem17.Size = new System.Drawing.Size(736, 20);
            this.emptySpaceItem17.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem18
            // 
            this.emptySpaceItem18.AllowHotTrack = false;
            this.emptySpaceItem18.Location = new System.Drawing.Point(0, 142);
            this.emptySpaceItem18.Name = "emptySpaceItem18";
            this.emptySpaceItem18.Size = new System.Drawing.Size(573, 10);
            this.emptySpaceItem18.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem19
            // 
            this.emptySpaceItem19.AllowHotTrack = false;
            this.emptySpaceItem19.Location = new System.Drawing.Point(0, 186);
            this.emptySpaceItem19.Name = "emptySpaceItem19";
            this.emptySpaceItem19.Size = new System.Drawing.Size(736, 19);
            this.emptySpaceItem19.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem20
            // 
            this.emptySpaceItem20.AllowHotTrack = false;
            this.emptySpaceItem20.Location = new System.Drawing.Point(0, 239);
            this.emptySpaceItem20.Name = "emptySpaceItem20";
            this.emptySpaceItem20.Size = new System.Drawing.Size(736, 21);
            this.emptySpaceItem20.TextSize = new System.Drawing.Size(0, 0);
            // 
            // cb_Pod
            // 
            this.cb_Pod.Location = new System.Drawing.Point(1154, 12);
            this.cb_Pod.Name = "cb_Pod";
            this.cb_Pod.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.cb_Pod.Properties.Appearance.Options.UseFont = true;
            this.cb_Pod.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cb_Pod.Size = new System.Drawing.Size(254, 30);
            this.cb_Pod.StyleController = this.layoutControl2;
            this.cb_Pod.TabIndex = 9;
            // 
            // cb_Pol
            // 
            this.cb_Pol.Location = new System.Drawing.Point(644, 12);
            this.cb_Pol.Name = "cb_Pol";
            this.cb_Pol.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.cb_Pol.Properties.Appearance.Options.UseFont = true;
            this.cb_Pol.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cb_Pol.Size = new System.Drawing.Size(234, 30);
            this.cb_Pol.StyleController = this.layoutControl2;
            this.cb_Pol.TabIndex = 8;
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.AppearanceGroup.Font = new System.Drawing.Font("Tahoma", 12F);
            this.layoutControlGroup1.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem13,
            this.layoutControlItem14,
            this.layoutControlItem7,
            this.layoutControlItem3,
            this.layoutControlItem10,
            this.layoutControlItem31,
            this.layoutControlItem15,
            this.layoutControlItem22,
            this.layoutControlItem5,
            this.layoutControlItem32,
            this.layoutControlItem1,
            this.layoutControlItem33,
            this.layoutControlItem34,
            this.layoutControlItem35,
            this.emptySpaceItem6,
            this.emptySpaceItem7,
            this.emptySpaceItem8,
            this.emptySpaceItem9,
            this.layoutControlItem2,
            this.layoutControlItem11,
            this.layoutControlItem36,
            this.layoutControlItem23,
            this.layoutControlItem24,
            this.layoutControlItem40,
            this.emptySpaceItem3});
            this.layoutControlGroup1.Name = "layoutControlGroup1";
            this.layoutControlGroup1.Size = new System.Drawing.Size(1551, 820);
            this.layoutControlGroup1.TextVisible = false;
            // 
            // layoutControlItem13
            // 
            this.layoutControlItem13.Control = this.groupControl2;
            this.layoutControlItem13.Location = new System.Drawing.Point(0, 305);
            this.layoutControlItem13.Name = "layoutControlItem13";
            this.layoutControlItem13.Size = new System.Drawing.Size(764, 495);
            this.layoutControlItem13.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem13.TextVisible = false;
            // 
            // layoutControlItem14
            // 
            this.layoutControlItem14.Control = this.groupControl3;
            this.layoutControlItem14.Location = new System.Drawing.Point(764, 305);
            this.layoutControlItem14.Name = "layoutControlItem14";
            this.layoutControlItem14.Size = new System.Drawing.Size(767, 495);
            this.layoutControlItem14.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem14.TextVisible = false;
            // 
            // layoutControlItem7
            // 
            this.layoutControlItem7.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.layoutControlItem7.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem7.Control = this.txtREF;
            this.layoutControlItem7.Location = new System.Drawing.Point(0, 138);
            this.layoutControlItem7.Name = "layoutControlItem7";
            this.layoutControlItem7.Size = new System.Drawing.Size(764, 34);
            this.layoutControlItem7.Text = "REF";
            this.layoutControlItem7.TextSize = new System.Drawing.Size(109, 24);
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.layoutControlItem3.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem3.Control = this.txtHBL;
            this.layoutControlItem3.Location = new System.Drawing.Point(510, 92);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(509, 34);
            this.layoutControlItem3.Text = "HBL";
            this.layoutControlItem3.TextSize = new System.Drawing.Size(109, 24);
            // 
            // layoutControlItem10
            // 
            this.layoutControlItem10.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.layoutControlItem10.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem10.Control = this.txtSize;
            this.layoutControlItem10.Location = new System.Drawing.Point(764, 138);
            this.layoutControlItem10.Name = "layoutControlItem10";
            this.layoutControlItem10.Size = new System.Drawing.Size(767, 34);
            this.layoutControlItem10.Text = "Size";
            this.layoutControlItem10.TextSize = new System.Drawing.Size(109, 24);
            // 
            // layoutControlItem31
            // 
            this.layoutControlItem31.Control = this.sb_CrearAgente;
            this.layoutControlItem31.Location = new System.Drawing.Point(341, 0);
            this.layoutControlItem31.Name = "layoutControlItem31";
            this.layoutControlItem31.Size = new System.Drawing.Size(170, 34);
            this.layoutControlItem31.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem31.TextVisible = false;
            // 
            // layoutControlItem15
            // 
            this.layoutControlItem15.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.layoutControlItem15.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem15.Control = this.txtBK;
            this.layoutControlItem15.Location = new System.Drawing.Point(0, 92);
            this.layoutControlItem15.Name = "layoutControlItem15";
            this.layoutControlItem15.Size = new System.Drawing.Size(510, 34);
            this.layoutControlItem15.Text = "BK #";
            this.layoutControlItem15.TextSize = new System.Drawing.Size(109, 24);
            // 
            // layoutControlItem22
            // 
            this.layoutControlItem22.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.layoutControlItem22.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem22.Control = this.txtMBL;
            this.layoutControlItem22.Location = new System.Drawing.Point(1019, 92);
            this.layoutControlItem22.Name = "layoutControlItem22";
            this.layoutControlItem22.Size = new System.Drawing.Size(512, 34);
            this.layoutControlItem22.Text = "MBL";
            this.layoutControlItem22.TextSize = new System.Drawing.Size(109, 24);
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.layoutControlItem5.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem5.Control = this.cb_Pol;
            this.layoutControlItem5.Location = new System.Drawing.Point(511, 0);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(359, 34);
            this.layoutControlItem5.Text = "POL";
            this.layoutControlItem5.TextSize = new System.Drawing.Size(109, 24);
            // 
            // layoutControlItem32
            // 
            this.layoutControlItem32.Control = this.sb_CrearPol;
            this.layoutControlItem32.Location = new System.Drawing.Point(870, 0);
            this.layoutControlItem32.Name = "layoutControlItem32";
            this.layoutControlItem32.Size = new System.Drawing.Size(151, 34);
            this.layoutControlItem32.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem32.TextVisible = false;
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.AppearanceItemCaption.Font = new System.Drawing.Font("Verdana", 12F);
            this.layoutControlItem1.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem1.Control = this.cb_Pod;
            this.layoutControlItem1.Location = new System.Drawing.Point(1021, 0);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(379, 34);
            this.layoutControlItem1.Text = "POD";
            this.layoutControlItem1.TextSize = new System.Drawing.Size(109, 25);
            // 
            // layoutControlItem33
            // 
            this.layoutControlItem33.Control = this.sb_CrearPod;
            this.layoutControlItem33.Location = new System.Drawing.Point(1400, 0);
            this.layoutControlItem33.Name = "layoutControlItem33";
            this.layoutControlItem33.Size = new System.Drawing.Size(131, 34);
            this.layoutControlItem33.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem33.TextVisible = false;
            // 
            // layoutControlItem34
            // 
            this.layoutControlItem34.Control = this.sb_CrearCarrier;
            this.layoutControlItem34.Location = new System.Drawing.Point(384, 46);
            this.layoutControlItem34.Name = "layoutControlItem34";
            this.layoutControlItem34.Size = new System.Drawing.Size(385, 34);
            this.layoutControlItem34.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem34.TextVisible = false;
            // 
            // layoutControlItem35
            // 
            this.layoutControlItem35.Control = this.sb_CrearConsignee;
            this.layoutControlItem35.Location = new System.Drawing.Point(1148, 46);
            this.layoutControlItem35.Name = "layoutControlItem35";
            this.layoutControlItem35.Size = new System.Drawing.Size(383, 34);
            this.layoutControlItem35.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem35.TextVisible = false;
            // 
            // emptySpaceItem6
            // 
            this.emptySpaceItem6.AllowHotTrack = false;
            this.emptySpaceItem6.Location = new System.Drawing.Point(0, 34);
            this.emptySpaceItem6.Name = "emptySpaceItem6";
            this.emptySpaceItem6.Size = new System.Drawing.Size(1531, 12);
            this.emptySpaceItem6.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem7
            // 
            this.emptySpaceItem7.AllowHotTrack = false;
            this.emptySpaceItem7.Location = new System.Drawing.Point(0, 80);
            this.emptySpaceItem7.Name = "emptySpaceItem7";
            this.emptySpaceItem7.Size = new System.Drawing.Size(1531, 12);
            this.emptySpaceItem7.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem8
            // 
            this.emptySpaceItem8.AllowHotTrack = false;
            this.emptySpaceItem8.Location = new System.Drawing.Point(0, 126);
            this.emptySpaceItem8.Name = "emptySpaceItem8";
            this.emptySpaceItem8.Size = new System.Drawing.Size(1531, 12);
            this.emptySpaceItem8.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem9
            // 
            this.emptySpaceItem9.AllowHotTrack = false;
            this.emptySpaceItem9.Location = new System.Drawing.Point(0, 172);
            this.emptySpaceItem9.Name = "emptySpaceItem9";
            this.emptySpaceItem9.Size = new System.Drawing.Size(1531, 12);
            this.emptySpaceItem9.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 12F);
            this.layoutControlItem2.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem2.Control = this.cb_agente;
            this.layoutControlItem2.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(341, 34);
            this.layoutControlItem2.Text = "Agente";
            this.layoutControlItem2.TextSize = new System.Drawing.Size(109, 24);
            // 
            // layoutControlItem11
            // 
            this.layoutControlItem11.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 12F);
            this.layoutControlItem11.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem11.Control = this.cb_carrier;
            this.layoutControlItem11.Location = new System.Drawing.Point(0, 46);
            this.layoutControlItem11.Name = "layoutControlItem11";
            this.layoutControlItem11.Size = new System.Drawing.Size(384, 34);
            this.layoutControlItem11.Text = "Carrier";
            this.layoutControlItem11.TextSize = new System.Drawing.Size(109, 24);
            // 
            // layoutControlItem36
            // 
            this.layoutControlItem36.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 12F);
            this.layoutControlItem36.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem36.Control = this.cb_consignee;
            this.layoutControlItem36.Location = new System.Drawing.Point(769, 46);
            this.layoutControlItem36.Name = "layoutControlItem36";
            this.layoutControlItem36.Size = new System.Drawing.Size(379, 34);
            this.layoutControlItem36.Text = "Consignee";
            this.layoutControlItem36.TextSize = new System.Drawing.Size(109, 24);
            // 
            // layoutControlItem23
            // 
            this.layoutControlItem23.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 12F);
            this.layoutControlItem23.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem23.Control = this.dt_ETD;
            this.layoutControlItem23.CustomizationFormText = "layoutControlItem23";
            this.layoutControlItem23.Location = new System.Drawing.Point(0, 184);
            this.layoutControlItem23.Name = "layoutControlItem23";
            this.layoutControlItem23.Size = new System.Drawing.Size(764, 34);
            this.layoutControlItem23.Text = "ETD";
            this.layoutControlItem23.TextSize = new System.Drawing.Size(109, 24);
            // 
            // layoutControlItem24
            // 
            this.layoutControlItem24.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 12F);
            this.layoutControlItem24.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem24.Control = this.dt_ETA;
            this.layoutControlItem24.Location = new System.Drawing.Point(764, 184);
            this.layoutControlItem24.Name = "layoutControlItem24";
            this.layoutControlItem24.Size = new System.Drawing.Size(767, 34);
            this.layoutControlItem24.Text = "ETA";
            this.layoutControlItem24.TextSize = new System.Drawing.Size(109, 24);
            // 
            // layoutControlItem40
            // 
            this.layoutControlItem40.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 12F);
            this.layoutControlItem40.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlItem40.Control = this.txtDescripcion;
            this.layoutControlItem40.Location = new System.Drawing.Point(0, 230);
            this.layoutControlItem40.Name = "layoutControlItem40";
            this.layoutControlItem40.Size = new System.Drawing.Size(1531, 75);
            this.layoutControlItem40.Text = "Descripcion:";
            this.layoutControlItem40.TextSize = new System.Drawing.Size(109, 24);
            // 
            // emptySpaceItem3
            // 
            this.emptySpaceItem3.AllowHotTrack = false;
            this.emptySpaceItem3.Location = new System.Drawing.Point(0, 218);
            this.emptySpaceItem3.Name = "emptySpaceItem3";
            this.emptySpaceItem3.Size = new System.Drawing.Size(1531, 12);
            this.emptySpaceItem3.TextSize = new System.Drawing.Size(0, 0);
            // 
            // Root
            // 
            this.Root.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.Root.GroupBordersVisible = false;
            this.Root.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem1,
            this.layoutControlItem12,
            this.layoutControlItem9,
            this.layoutControlItem16,
            this.emptySpaceItem4});
            this.Root.Name = "Root";
            this.Root.Size = new System.Drawing.Size(1579, 939);
            this.Root.TextVisible = false;
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.Location = new System.Drawing.Point(0, 894);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(1559, 25);
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem12
            // 
            this.layoutControlItem12.Control = this.groupControl1;
            this.layoutControlItem12.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem12.Name = "layoutControlItem12";
            this.layoutControlItem12.Size = new System.Drawing.Size(1559, 854);
            this.layoutControlItem12.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem12.TextVisible = false;
            // 
            // layoutControlItem9
            // 
            this.layoutControlItem9.Control = this.simpleButton1;
            this.layoutControlItem9.Location = new System.Drawing.Point(807, 854);
            this.layoutControlItem9.Name = "layoutControlItem9";
            this.layoutControlItem9.Size = new System.Drawing.Size(372, 40);
            this.layoutControlItem9.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem9.TextVisible = false;
            // 
            // layoutControlItem16
            // 
            this.layoutControlItem16.Control = this.simpleButton2;
            this.layoutControlItem16.Location = new System.Drawing.Point(1179, 854);
            this.layoutControlItem16.Name = "layoutControlItem16";
            this.layoutControlItem16.Size = new System.Drawing.Size(380, 40);
            this.layoutControlItem16.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem16.TextVisible = false;
            // 
            // emptySpaceItem4
            // 
            this.emptySpaceItem4.AllowHotTrack = false;
            this.emptySpaceItem4.Location = new System.Drawing.Point(0, 854);
            this.emptySpaceItem4.Name = "emptySpaceItem4";
            this.emptySpaceItem4.Size = new System.Drawing.Size(807, 40);
            this.emptySpaceItem4.TextSize = new System.Drawing.Size(0, 0);
            // 
            // Frm_Resumen_Add
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1579, 939);
            this.Controls.Add(this.layoutControl1);
            this.Name = "Frm_Resumen_Add";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Frm_Resumen_Add";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Frm_Resumen_Add_Load);
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).EndInit();
            this.layoutControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl2)).EndInit();
            this.layoutControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtDescripcion.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dt_ETA.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dt_ETA.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dt_ETD.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dt_ETD.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cb_consignee.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cb_carrier.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cb_agente.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSize.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtREF.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHBL.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMBL.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl3)).EndInit();
            this.groupControl3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl3)).EndInit();
            this.layoutControl3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtTlocal.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCVLocal.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDGastos.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOtros.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTHC.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtINLAN.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOM.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBK.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).EndInit();
            this.groupControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl4)).EndInit();
            this.layoutControl4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl4)).EndInit();
            this.groupControl4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl5)).EndInit();
            this.layoutControl5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtTEspecial.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtReintegro.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRebate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cb_incoterm.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOTotal.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtQuotation.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPAgent.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOf.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cb_Pod.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cb_Pol.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Root)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.behaviorManager1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraLayout.LayoutControl layoutControl1;
        private DevExpress.XtraLayout.LayoutControlGroup Root;
        private DevExpress.XtraEditors.ComboBoxEdit cb_Pol;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private DevExpress.XtraLayout.LayoutControl layoutControl2;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraEditors.GroupControl groupControl3;
        private DevExpress.XtraEditors.GroupControl groupControl2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem12;
        private DevExpress.XtraEditors.ComboBoxEdit cb_Pod;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraEditors.SimpleButton simpleButton2;
        private DevExpress.XtraEditors.SimpleButton simpleButton1;
        private DevExpress.XtraLayout.LayoutControl layoutControl3;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private DevExpress.XtraEditors.TextEdit txtBK;
        private DevExpress.XtraLayout.LayoutControl layoutControl4;
        private DevExpress.XtraEditors.TextEdit txtPAgent;
        private DevExpress.XtraEditors.TextEdit txtOf;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem20;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem13;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem14;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem9;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem16;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem4;
        private DevExpress.XtraEditors.TextEdit txtOtros;
        private DevExpress.XtraEditors.TextEdit txtTHC;
        private DevExpress.XtraEditors.TextEdit txtINLAN;
        private DevExpress.XtraEditors.TextEdit txtOM;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem17;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem18;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem19;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem21;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem15;
        private DevExpress.XtraEditors.TextEdit txtSize;
        private DevExpress.XtraEditors.TextEdit txtREF;
        private DevExpress.XtraEditors.TextEdit txtHBL;
        private DevExpress.XtraEditors.TextEdit txtMBL;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem22;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem7;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem10;
        private DevExpress.XtraEditors.TextEdit txtCVLocal;
        private DevExpress.XtraEditors.TextEdit txtDGastos;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem26;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem27;
        private DevExpress.XtraEditors.TextEdit txtOTotal;
        private DevExpress.XtraEditors.TextEdit txtQuotation;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem8;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem25;
        private DevExpress.XtraEditors.GroupControl groupControl4;
        private DevExpress.XtraLayout.LayoutControl layoutControl5;
        private DevExpress.XtraEditors.TextEdit txtReintegro;
        private DevExpress.XtraEditors.TextEdit txtRebate;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup4;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem29;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem30;
        private DevExpress.XtraEditors.SimpleButton sb_CrearConsignee;
        private DevExpress.XtraEditors.SimpleButton sb_CrearCarrier;
        private DevExpress.XtraEditors.SimpleButton sb_CrearPod;
        private DevExpress.XtraEditors.SimpleButton sb_CrearPol;
        private DevExpress.XtraEditors.SimpleButton sb_CrearAgente;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem31;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem32;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem33;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem34;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem35;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem6;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem7;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem8;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem9;
        private DevExpress.XtraEditors.ComboBoxEdit cb_carrier;
        private DevExpress.XtraEditors.ComboBoxEdit cb_agente;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem11;
        private DevExpress.XtraEditors.ComboBoxEdit cb_consignee;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem36;
        private DevExpress.XtraEditors.DateEdit dt_ETA;
        private DevExpress.XtraEditors.DateEdit dt_ETD;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem23;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem24;
        private DevExpress.XtraEditors.ComboBoxEdit cb_incoterm;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private DevExpress.XtraEditors.SimpleButton sb_CrearIncoterm;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem37;
        private DevExpress.XtraEditors.MemoEdit txtDescripcion;
        private DevExpress.XtraEditors.TextEdit txtTlocal;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem38;
        private DevExpress.XtraEditors.TextEdit txtTEspecial;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem39;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem28;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem40;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem3;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem10;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem11;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem12;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem13;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem14;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem15;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem21;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem22;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem16;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem17;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem18;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem19;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem20;
        private DevExpress.Utils.Behaviors.BehaviorManager behaviorManager1;
    }
}