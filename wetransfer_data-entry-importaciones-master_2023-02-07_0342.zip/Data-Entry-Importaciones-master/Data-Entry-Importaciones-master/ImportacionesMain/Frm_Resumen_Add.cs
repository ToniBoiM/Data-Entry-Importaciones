﻿using DevExpress.XtraEditors;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImportacionesMain
{
    public partial class Frm_Resumen_Add : DevExpress.XtraEditors.XtraForm
    {
        public Frm_Resumen_Add()
        {
            InitializeComponent();
        }

        private void Frm_Resumen_Add_Load(object sender, EventArgs e)
        {
            List<string> s;
            s = BaseDatos.CargarAgentes().AsEnumerable().Select(x => x[1].ToString()).ToList();
            cb_agente.Properties.Items.AddRange(s);
            s = BaseDatos.CargarConsigneer().AsEnumerable().Select(x => x[1].ToString()).ToList();
            cb_consignee.Properties.Items.AddRange(s);
            s = BaseDatos.CargarCarrier().AsEnumerable().Select(x => x[1].ToString()).ToList();
            cb_carrier.Properties.Items.AddRange(s);
            s = BaseDatos.CargarPOL().AsEnumerable().Select(x => x[1].ToString()).ToList();
            cb_Pol.Properties.Items.AddRange(s);
            s = BaseDatos.CargarPOD().AsEnumerable().Select(x => x[1].ToString()).ToList();
            cb_Pod.Properties.Items.AddRange(s);
            s = BaseDatos.CargarIncoterm().AsEnumerable().Select(x => x[1].ToString()).ToList();
            cb_incoterm.Properties.Items.AddRange(s);
        }

        private void sb_CrearAgente_Click(object sender, EventArgs e)
        {
            Anadir anadir = new Anadir();
            anadir.tabla = "Agente";
            anadir.ShowDialog();
            cb_agente.Properties.Items.Clear();
            List<string> s;
            s = BaseDatos.CargarAgentes().AsEnumerable().Select(x => x[1].ToString()).ToList();
            cb_agente.Properties.Items.AddRange(s);
        }

        private void sb_CrearCarrier_Click(object sender, EventArgs e)
        {
            Anadir anadir = new Anadir();
            anadir.tabla = "Carrier";
            anadir.ShowDialog();
            cb_carrier.Properties.Items.Clear();
            List<string> s;
            s = BaseDatos.CargarCarrier().AsEnumerable().Select(x => x[1].ToString()).ToList();
            cb_carrier.Properties.Items.AddRange(s);
        }

        private void sb_CrearPol_Click(object sender, EventArgs e)
        {
            Anadir anadir = new Anadir();
            anadir.tabla = "Pol";
            anadir.ShowDialog();
            cb_Pol.Properties.Items.Clear();
            List<string> s;
            s = BaseDatos.CargarPOL().AsEnumerable().Select(x => x[1].ToString()).ToList();
            cb_Pol.Properties.Items.AddRange(s);
        }

        private void sb_CrearPod_Click(object sender, EventArgs e)
        {
            Anadir anadir = new Anadir();
            anadir.tabla = "Pod";
            anadir.ShowDialog();
            cb_Pod.Properties.Items.Clear();
            List<string> s;
            s = BaseDatos.CargarPOD().AsEnumerable().Select(x => x[1].ToString()).ToList();
            cb_Pod.Properties.Items.AddRange(s);
        }

        private void sb_CrearConsignee_Click(object sender, EventArgs e)
        {
            Anadir anadir = new Anadir();
            anadir.tabla = "Consigneer";
            anadir.ShowDialog();
            cb_consignee.Properties.Items.Clear();
            List<string> s;
            s = BaseDatos.CargarConsigneer().AsEnumerable().Select(x => x[1].ToString()).ToList();
            cb_consignee.Properties.Items.AddRange(s);
        }

        private void sb_CrearIncoterm_Click(object sender, EventArgs e)
        {
            Anadir anadir = new Anadir();
            anadir.tabla = "Incoterm";
            anadir.ShowDialog();
            cb_incoterm.Properties.Items.Clear();
            List<string> s;
            s = BaseDatos.CargarIncoterm().AsEnumerable().Select(x => x[1].ToString()).ToList();
            cb_incoterm.Properties.Items.AddRange(s);
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            BaseDatos.GuardarReporte(cb_agente.Text, cb_Pol.Text, cb_Pod.Text, cb_carrier.Text, cb_consignee.Text, txtBK.Text, 
                txtHBL.Text, txtMBL.Text, int.Parse(txtREF.Text), txtSize.Text, (DateTime) dt_ETD.EditValue, (DateTime) dt_ETA.EditValue, 
                txtDescripcion.Text, float.Parse(txtOf.EditValue.ToString()), float.Parse(txtPAgent.Text), cb_incoterm.Text, float.Parse(txtQuotation.Text), float.Parse(txtOTotal.Text), float.Parse(txtOM.Text), float.Parse(txtINLAN.Text),
                float.Parse(txtTHC.Text), txtDGastos.Text, float.Parse(txtCVLocal.Text), float.Parse(txtTlocal.Text), float.Parse(txtRebate.Text), float.Parse(txtReintegro.Text), float.Parse(txtTEspecial.Text));

            string prueba;
            float pruaba;
            DateTime pruebo;

            prueba = cb_agente.Text;
            prueba = cb_Pol.Text;
            prueba = cb_Pod.Text;
            prueba = cb_carrier.Text;
            prueba = cb_consignee.Text;
            prueba = txtBK.Text;
            prueba = txtHBL.Text;
            prueba = txtMBL.Text;
            pruaba = float.Parse(txtREF.Text);
            prueba = txtSize.Text;
            pruebo = (DateTime)dt_ETD.EditValue;
            pruebo = (DateTime)dt_ETA.EditValue;
            prueba = txtDescripcion.Text;
            pruaba = float.Parse(txtOf.Text);
            pruaba = float.Parse(txtPAgent.Text);
            prueba = cb_incoterm.Text;
            pruaba = float.Parse(txtQuotation.Text);
            pruaba = float.Parse(txtOTotal.Text);
            pruaba = float.Parse(txtOM.Text);
            pruaba = float.Parse(txtINLAN.Text);
            pruaba = float.Parse(txtTHC.Text);
            prueba = txtDGastos.Text;
            pruaba = float.Parse(txtCVLocal.Text);
            pruaba = float.Parse(txtTlocal.Text);
            pruaba = float.Parse(txtRebate.Text);
            pruaba = float.Parse(txtReintegro.Text);
            pruaba = float.Parse(txtTEspecial.Text);


        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtOf_EditValueChanged(object sender, EventArgs e)
        {
            
        }

        private void txtPAgent_EditValueChanged(object sender, EventArgs e)
        {

        }

        private void txtQuotation_EditValueChanged(object sender, EventArgs e)
        {

        }

        private void txtOf_Leave(object sender, EventArgs e)
        {
            float of, pagent, quotation;

            try
            {
                of = float.Parse(txtOf.EditValue.ToString());
            }
            catch
            {
                of = 0;
            }

            try
            {
                pagent = float.Parse(txtPAgent.Text);
            }
            catch
            {
                pagent = 0;
            }

            try
            {
                quotation = float.Parse(txtQuotation.Text);
            }
            catch
            {
                quotation = 0;
            }
            //MessageBox.Show(of.ToString() + " " + pagent.ToString() + " " + quotation.ToString() + " ");
            txtOTotal.Text = (of + pagent + quotation).ToString();
        }

        private void txtPAgent_Leave(object sender, EventArgs e)
        {
            float of, pagent, quotation;

            try
            {
                of = float.Parse(txtOf.EditValue.ToString());
            }
            catch
            {
                of = 0;
            }

            try
            {
                pagent = float.Parse(txtPAgent.Text);
            }
            catch
            {
                pagent = 0;
            }

            try
            {
                quotation = float.Parse(txtQuotation.Text);
            }
            catch
            {
                quotation = 0;
            }
            //MessageBox.Show(of.ToString() + " " + pagent.ToString() + " " + quotation.ToString() + " ");
            txtOTotal.Text = (of + pagent + quotation).ToString();
        }

        private void txtQuotation_Leave(object sender, EventArgs e)
        {
            float of, pagent, quotation;

            try
            {
                of = float.Parse(txtOf.EditValue.ToString());
            }
            catch
            {
                of = 0;
            }

            try
            {
                pagent = float.Parse(txtPAgent.Text);
            }
            catch
            {
                pagent = 0;
            }

            try
            {
                quotation = float.Parse(txtQuotation.Text);
            }
            catch
            {
                quotation = 0;
            }
            //MessageBox.Show(of.ToString() + " " + pagent.ToString() + " " + quotation.ToString() + " ");
            txtOTotal.Text = (of + pagent + quotation).ToString();
        }
    } 
}