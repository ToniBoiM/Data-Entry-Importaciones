﻿using DevExpress.XtraEditors;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImportacionesMain
{
    public partial class Prueba : DevExpress.XtraEditors.XtraForm
    {
        public Prueba()
        {
            InitializeComponent();
        }
    }
}